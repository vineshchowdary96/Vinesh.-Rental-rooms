# StayEasy full project
- backend/  : Node + Express + Razorpay (see backend/README.md)
- frontend/ : index.html (booking flow with UPI via Razorpay)
Run: cd backend && npm install && npm start, then open frontend/index.html.
Change apiBase in frontend/index.html when the backend is hosted online.
