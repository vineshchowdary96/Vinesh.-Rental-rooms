StayEasy - live payments page (needs the backend from zip 3)
1. Start the backend (zip 3).
2. Open index.html. If your server is not at http://localhost:3000,
   change apiBase near the top of the <script>.
