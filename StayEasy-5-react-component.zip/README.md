# UpiPayment.jsx - drop-in React component
Copy into your React project and render it after the booking details step:
<UpiPayment amount={total} bookingId={id} hotelName={name} merchantVpa="you@bank" onSubmitted={...} />
Confirm bookings only after your server verifies the payment (see the note at the bottom of the file).
