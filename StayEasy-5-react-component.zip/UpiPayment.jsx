import { useMemo, useState } from "react";

/**
 * UPI payment step for StayEasy.
 * Show this after the guest fills in booking details and BEFORE the
 * "Booking confirmed" screen. Only confirm the booking once your server
 * has verified the payment (see the note at the bottom of this file).
 *
 * Props
 *  - amount:        total to pay in INR (number)
 *  - bookingId:     your booking / order reference (string)
 *  - hotelName:     shown in the UPI note (string)
 *  - merchantVpa:   your receiving UPI ID, e.g. "stayeasy@okhdfcbank"
 *  - merchantName:  payee name shown in the UPI app
 *  - onSubmitted:   async ({ method, upiId?, utr? }) => void
 *                   call your backend here; confirm booking only on success
 */

const UPI_ID_PATTERN = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/;
const UTR_PATTERN = /^\d{12}$/;

const APPS = [
  { key: "gpay", label: "Google Pay", scheme: "tez://upi/pay" },
  { key: "phonepe", label: "PhonePe", scheme: "phonepe://pay" },
  { key: "paytm", label: "Paytm", scheme: "paytmmp://pay" },
  { key: "any", label: "Other UPI app", scheme: "upi://pay" },
];

export default function UpiPayment({
  amount,
  bookingId,
  hotelName,
  merchantVpa,
  merchantName = "StayEasy",
  onSubmitted,
}) {
  const [mode, setMode] = useState("app"); // "app" | "id"
  const [upiId, setUpiId] = useState("");
  const [utr, setUtr] = useState("");
  const [step, setStep] = useState("choose"); // "choose" | "awaiting" | "done"
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const query = useMemo(() => {
    const p = new URLSearchParams({
      pa: merchantVpa,
      pn: merchantName,
      am: Number(amount).toFixed(2),
      cu: "INR",
      tn: `StayEasy ${bookingId}${hotelName ? " - " + hotelName : ""}`.slice(0, 80),
      tr: bookingId,
    });
    return p.toString();
  }, [merchantVpa, merchantName, amount, bookingId, hotelName]);

  const openApp = (scheme) => {
    setError("");
    window.location.href = `${scheme}?${query}`;
    setStep("awaiting");
  };

  const sendCollectRequest = async () => {
    if (!UPI_ID_PATTERN.test(upiId.trim())) {
      setError("Enter a valid UPI ID, like name@bank.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      // Your server sends the collect request through your payment gateway.
      await onSubmitted({ method: "collect", upiId: upiId.trim() });
      setStep("awaiting");
    } catch (e) {
      setError(e?.message || "Could not send the request. Try again.");
    } finally {
      setBusy(false);
    }
  };

  const submitUtr = async () => {
    if (!UTR_PATTERN.test(utr.trim())) {
      setError("The UTR / reference number is 12 digits.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      await onSubmitted({ method: "intent", utr: utr.trim() });
      setStep("done");
    } catch (e) {
      setError(e?.message || "We could not verify this payment yet.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="upi-card" aria-labelledby="upi-title">
      <style>{css}</style>

      <div className="upi-head">
        <h2 id="upi-title">Pay with UPI</h2>
        <p className="upi-amount">₹{Number(amount).toLocaleString("en-IN")}</p>
      </div>
      <p className="upi-sub">
        Your room is held once payment goes through. You will get the
        confirmation right after.
      </p>

      {step === "choose" && (
        <>
          <div className="upi-tabs" role="tablist">
            <button
              role="tab"
              aria-selected={mode === "app"}
              className={mode === "app" ? "on" : ""}
              onClick={() => { setMode("app"); setError(""); }}
            >
              Open a UPI app
            </button>
            <button
              role="tab"
              aria-selected={mode === "id"}
              className={mode === "id" ? "on" : ""}
              onClick={() => { setMode("id"); setError(""); }}
            >
              Enter UPI ID
            </button>
          </div>

          {mode === "app" ? (
            <div className="upi-apps">
              {APPS.map((a) => (
                <button key={a.key} className="upi-app" onClick={() => openApp(a.scheme)}>
                  {a.label}
                </button>
              ))}
              <p className="upi-hint">
                On a computer? Pick "Enter UPI ID" and approve the request on your phone.
              </p>
            </div>
          ) : (
            <div className="upi-id">
              <label htmlFor="upi-id-input">Your UPI ID</label>
              <input
                id="upi-id-input"
                type="text"
                inputMode="email"
                autoComplete="off"
                placeholder="name@okhdfcbank"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
              />
              <button className="upi-pay" disabled={busy} onClick={sendCollectRequest}>
                {busy ? "Sending…" : `Send request for ₹${Number(amount).toLocaleString("en-IN")}`}
              </button>
            </div>
          )}
        </>
      )}

      {step === "awaiting" && (
        <div className="upi-wait">
          <p>
            Approve the payment in your UPI app, then enter the 12-digit UTR /
            reference number shown there.
          </p>
          <label htmlFor="upi-utr">UTR / reference number</label>
          <input
            id="upi-utr"
            type="text"
            inputMode="numeric"
            maxLength={12}
            placeholder="123456789012"
            value={utr}
            onChange={(e) => setUtr(e.target.value.replace(/\D/g, ""))}
          />
          <button className="upi-pay" disabled={busy} onClick={submitUtr}>
            {busy ? "Verifying…" : "Confirm payment"}
          </button>
          <button className="upi-link" onClick={() => { setStep("choose"); setError(""); }}>
            Choose a different way to pay
          </button>
        </div>
      )}

      {step === "done" && (
        <div className="upi-done" role="status">
          Payment received. Confirming your booking…
        </div>
      )}

      {error && <p className="upi-error" role="alert">{error}</p>}
    </section>
  );
}

/*
 * IMPORTANT: a UPI deep link cannot tell your site whether the payment
 * succeeded. Anyone could type a fake UTR. Before confirming a booking:
 *   1. Create the payment order on your server through a gateway that
 *      supports UPI (Razorpay, Cashfree, PhonePe PG, PayU).
 *   2. Confirm the booking only when the gateway's webhook (or a status
 *      API call from your server) reports the payment as captured.
 *   3. Never mark a booking paid based on client-side data alone.
 * Keep merchantVpa in config, not hard-coded in several places.
 */

const css = `
.upi-card{background:var(--card-bg,#fff);border:1px solid var(--border,#e5e7eb);border-radius:12px;padding:20px;max-width:440px;font-family:Poppins,-apple-system,"Segoe UI",sans-serif;color:var(--text,#1a1a2e)}
.upi-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px}
.upi-head h2{font-size:1.15rem;font-weight:700;margin:0}
.upi-amount{font-size:1.25rem;font-weight:700;color:var(--primary,#ee2c5b);margin:0}
.upi-sub{font-size:.85rem;color:var(--text-light,#6b7280);margin:6px 0 16px;line-height:1.5}
.upi-tabs{display:flex;border:1px solid var(--border,#e5e7eb);border-radius:8px;overflow:hidden;margin-bottom:14px}
.upi-tabs button{flex:1;padding:10px;border:0;background:transparent;font:inherit;font-size:.85rem;font-weight:500;color:var(--text-light,#6b7280);cursor:pointer}
.upi-tabs button.on{background:var(--secondary,#1a1a2e);color:#fff}
.upi-apps{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.upi-app{padding:12px;border:1px solid var(--border,#e5e7eb);border-radius:8px;background:#fff;font:inherit;font-size:.85rem;font-weight:500;cursor:pointer;color:var(--text,#1a1a2e)}
.upi-app:hover{border-color:var(--primary,#ee2c5b)}
.upi-hint{grid-column:1/-1;font-size:.78rem;color:var(--text-light,#6b7280);margin:4px 0 0}
.upi-id,.upi-wait{display:flex;flex-direction:column;gap:10px}
.upi-wait p{font-size:.85rem;line-height:1.5;margin:0}
.upi-card label{font-size:.8rem;font-weight:600}
.upi-card input{padding:12px;border:1px solid var(--border,#e5e7eb);border-radius:8px;font:inherit;font-size:.95rem}
.upi-card input:focus{outline:2px solid var(--primary,#ee2c5b);outline-offset:1px}
.upi-pay{padding:13px;border:0;border-radius:8px;background:var(--primary,#ee2c5b);color:#fff;font:inherit;font-weight:600;cursor:pointer}
.upi-pay:hover{background:var(--primary-dark,#c81f47)}
.upi-pay:disabled{opacity:.6;cursor:default}
.upi-link{background:none;border:0;color:var(--text-light,#6b7280);font:inherit;font-size:.8rem;text-decoration:underline;cursor:pointer;padding:0;align-self:flex-start}
.upi-done{padding:14px;border-radius:8px;background:#e8f6ee;color:var(--success,#17a558);font-weight:600;font-size:.9rem}
.upi-error{margin:12px 0 0;font-size:.82rem;color:#b42318}
`;
