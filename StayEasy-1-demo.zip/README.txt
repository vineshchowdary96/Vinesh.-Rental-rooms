StayEasy - UPI demo (front-end only)
Open index.html in a browser. Click a hotel to try the booking + UPI steps.
Set your UPI ID: edit merchantVpa near the top of the <script> in index.html.
NOTE: payment check is a demo (12-digit UTR format only). Not for real customers.
