/**
 * StayEasy backend: verified UPI payments with Razorpay.
 *
 * Setup
 *   1. npm init -y
 *   2. npm install express cors razorpay
 *   3. Set environment variables (use Razorpay TEST keys first):
 *        RAZORPAY_KEY_ID=rzp_test_xxx
 *        RAZORPAY_KEY_SECRET=xxx
 *        RAZORPAY_WEBHOOK_SECRET=xxx      (optional, for the webhook below)
 *        ALLOWED_ORIGIN=http://localhost:5500   (where your page is served from)
 *   4. node server.js
 *
 * Flow
 *   POST /api/orders  -> server works out the price and creates a Razorpay order
 *   (browser opens Razorpay Checkout, guest pays by UPI)
 *   POST /api/verify  -> server checks Razorpay's signature; only then is the booking confirmed
 *
 * The price is calculated HERE from the hotel name, never taken from the browser.
 */
const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const Razorpay = require("razorpay");

const { RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET } = process.env;
if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
  console.error("Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET first.");
  process.exit(1);
}

const razorpay = new Razorpay({ key_id: RAZORPAY_KEY_ID, key_secret: RAZORPAY_KEY_SECRET });
const TAX_RATE = 0.12;

// Price per night in INR. Keep this in sync with your hotel listings (or read it from your database).
const HOTELS = {
  "Blue Orchid Mumbai 2": 2240,
  "The Wanderer Delhi 4": 1470,
  "Royal Stay Udaipur 3": 770,
  "Sunrise Residency Pune": 940,
  "Metro Suites Pune 5": 1660,
  "Royal Stay Jaipur 3": 1140,
  "Sunrise Residency Manali": 1410,
  "Metro Suites Manali 5": 1460,
};

// In-memory store for the demo. Use a real database in production.
const orders = new Map();   // razorpay order id -> booking
const bookings = new Map(); // booking id -> confirmed booking

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || true }));

// The webhook needs the raw body, so it is registered before express.json().
app.post("/api/webhook", express.raw({ type: "application/json" }), (req, res) => {
  if (!RAZORPAY_WEBHOOK_SECRET) return res.sendStatus(404);
  const expected = crypto.createHmac("sha256", RAZORPAY_WEBHOOK_SECRET).update(req.body).digest("hex");
  const given = req.get("X-Razorpay-Signature") || "";
  if (!safeEqual(expected, given)) return res.sendStatus(400);
  const event = JSON.parse(req.body.toString());
  if (event.event === "payment.captured" || event.event === "order.paid") {
    const orderId = event.payload.payment.entity.order_id;
    const b = orders.get(orderId);
    if (b) confirm(b, event.payload.payment.entity.id);
  }
  res.sendStatus(200);
});

app.use(express.json());

app.post("/api/orders", async (req, res) => {
  try {
    const { hotel, checkIn, checkOut, rooms, guests, name, phone, email, bookingId } = req.body || {};
    const price = HOTELS[hotel];
    const nights = Math.round((new Date(checkOut) - new Date(checkIn)) / 864e5);
    const roomCount = Number(rooms);

    if (!price) return res.status(400).json({ error: "Unknown hotel." });
    if (!Number.isInteger(nights) || nights < 1 || nights > 30) return res.status(400).json({ error: "Invalid dates." });
    if (!Number.isInteger(roomCount) || roomCount < 1 || roomCount > 4) return res.status(400).json({ error: "Invalid room count." });
    if (!/^[6-9]\d{9}$/.test(String(phone))) return res.status(400).json({ error: "Invalid mobile number." });

    const total = price * nights * roomCount * (1 + TAX_RATE);
    const amountPaise = Math.round(total * 100);

    const order = await razorpay.orders.create({
      amount: amountPaise,
      currency: "INR",
      receipt: String(bookingId).slice(0, 40),
      notes: { hotel, checkIn, checkOut, rooms: String(roomCount), guests: String(guests), name },
    });

    orders.set(order.id, { bookingId, hotel, checkIn, checkOut, rooms: roomCount, guests, name, phone, email, amountPaise, status: "pending" });
    res.json({ orderId: order.id, amount: amountPaise, currency: "INR", keyId: RAZORPAY_KEY_ID });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start the payment." });
  }
});

app.post("/api/verify", async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  const booking = orders.get(razorpay_order_id);
  if (!booking) return res.status(404).json({ ok: false, error: "Order not found." });

  const expected = crypto
    .createHmac("sha256", RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");
  if (!safeEqual(expected, razorpay_signature || "")) {
    return res.status(400).json({ ok: false, error: "Payment could not be verified." });
  }

  // Second check straight with Razorpay: the amount and status must match.
  try {
    const p = await razorpay.payments.fetch(razorpay_payment_id);
    if (p.order_id !== razorpay_order_id || p.amount !== booking.amountPaise || !["captured", "authorized"].includes(p.status)) {
      return res.status(400).json({ ok: false, error: "Payment details do not match." });
    }
  } catch (err) {
    console.error(err);
    return res.status(502).json({ ok: false, error: "Could not reach the payment provider." });
  }

  confirm(booking, razorpay_payment_id);
  res.json({ ok: true, bookingId: booking.bookingId, paymentId: razorpay_payment_id });
});

function confirm(booking, paymentId) {
  if (booking.status === "confirmed") return;
  booking.status = "confirmed";
  booking.paymentId = paymentId;
  bookings.set(booking.bookingId, booking);
  // TODO: save to your database and send the confirmation email / SMS here.
  console.log("Booking confirmed:", booking.bookingId, paymentId);
}

function safeEqual(a, b) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`StayEasy API running on http://localhost:${PORT}`));
