# StayEasy backend (Razorpay UPI verification)
1. `npm install`
2. Export the variables from `.env.example` (use Razorpay TEST keys first), e.g.
   `export RAZORPAY_KEY_ID=... RAZORPAY_KEY_SECRET=...` (Windows PowerShell: `$env:RAZORPAY_KEY_ID="..."`)
3. `npm start` -> http://localhost:3000
Endpoints: POST /api/orders, POST /api/verify, POST /api/webhook (optional).
Bookings are kept in memory: add a database and email/SMS where server.js says TODO.
